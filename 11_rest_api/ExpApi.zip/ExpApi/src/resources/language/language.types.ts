export interface ChangeLanguageDTO{
   lang: 'pt-BR' | 'en-US';
}