export const enum UserTypes {
   "ADMIN" = "6c78aa4e-b15e-4228-be8c-58d899bf4136",
   "CLIENT" = "d12f4fa0-f970-442b-9430-7818b8d91808"
}