# Instruções para Executar a aplicação
- Rode o docker compose do diretório;
- Confira a aplicação no link [http://localhost:4444](http://localhost:4444).

